# Wet Blocks (Fabric 1.21.11, client)

Menu in-game untuk memilih blok yang **selalu basah dan memantul** di shader **iterationT**
(butuh patch `iterationT_AlwaysWet_patch.zip` terpasang di shader pack, dan Enable PBR = On).

## Cara pakai di game
1. Pasang jar mod di folder `mods` (bersama Fabric API) dan pilih shader pack iterationT.
2. Buka menu: ketik `/wetblocks` di chat, atau pakai keybind **Wet Blocks** di menu Controls (belum diberi tombol default).
3. Di menu:
   - Ketik nama blok di kotak cari, lalu tekan hasil `+ nama_blok` untuk menambah.
   - **Blok dilihat** menambah blok yang sedang kamu arahkan krosnya.
   - Tekan `[x] nama_blok` di daftar untuk menghapus. Tombol `<` `>` mengganti halaman.
   - `-` dan `+` di sebelah **Kekuatan** mengatur kekuatan pantulan (0.1 sampai 2.0).
   - **Terapkan** menulis daftar ke `block.properties` di shader pack, menyimpan kekuatan ke file opsi pack,
     lalu memuat ulang shader.
4. Daftar juga disimpan di `config/wetblocks.txt`.

## Build (GitHub Actions)
1. Upload seluruh isi folder ini ke repo GitHub.
2. Buka tab **Actions** -> workflow **build** (jalan otomatis saat push, atau tekan **Run workflow**).
3. Setelah hijau, buka run-nya, unduh artifact **Artifacts**, ambil `wetblocks-1.0.0.jar` (bukan yang `-sources`).

## Catatan teknis
- Mod tidak membaca data dari shader. Ia mengedit baris `block.7200` di `shaders/block.properties`
  (folder atau zip) dan opsi `ALWAYS_WET_STRENGTH` di `shaderpacks/<nama pack>.txt`, lalu memanggil `Iris.reload()` lewat reflection.
- Mappings: Mojang (resmi), Loom `net.fabricmc.fabric-loom-remap`, Fabric API 0.141.6+1.21.11.
