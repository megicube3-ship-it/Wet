package com.wetblocks;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WetBlocksScreen extends Screen {
	private static final int PAGE = 4;
	private static final int RESULTS = 4;

	private final Screen parent;
	private final List<String> blocks = new ArrayList<>();
	private int strength;
	private int page = 0;
	private String status = "";
	private String lookedAt = null;

	private EditBox search;
	private final Button[] resultButtons = new Button[RESULTS];
	private final String[] resultIds = new String[RESULTS];
	private final Button[] listButtons = new Button[PAGE];
	private Button prevButton;
	private Button nextButton;
	private Button lookedButton;

	public WetBlocksScreen(Screen parent) {
		super(Component.literal("Wet Blocks"));
		this.parent = parent;

		PackEditor.Config config = PackEditor.loadConfig();
		this.blocks.addAll(config.blocks);
		this.strength = config.strength;

		Minecraft mc = Minecraft.getInstance();
		if (mc.level != null && mc.hitResult != null && mc.hitResult.getType() == HitResult.Type.BLOCK) {
			Block block = mc.level.getBlockState(((BlockHitResult) mc.hitResult).getBlockPos()).getBlock();
			this.lookedAt = BuiltInRegistries.BLOCK.getKey(block).toString();
		}
	}

	@Override
	protected void init() {
		int cx = this.width / 2;
		int left = cx - 150;

		this.search = new EditBox(this.font, left, 20, 300, 18, Component.literal("Cari blok"));
		this.search.setMaxLength(64);
		this.search.setResponder(value -> updateResults());
		this.addRenderableWidget(this.search);

		for (int i = 0; i < RESULTS; i++) {
			final int index = i;
			int x = left + (i % 2) * 152;
			int y = 42 + (i / 2) * 22;
			this.resultButtons[i] = this.addRenderableWidget(Button.builder(Component.literal(""), button -> addResult(index))
					.pos(x, y).size(148, 20).build());
		}

		for (int i = 0; i < PAGE; i++) {
			final int index = i;
			int x = left + (i % 2) * 152;
			int y = 102 + (i / 2) * 22;
			this.listButtons[i] = this.addRenderableWidget(Button.builder(Component.literal(""), button -> removeAt(index))
					.pos(x, y).size(148, 20).build());
		}

		this.prevButton = this.addRenderableWidget(Button.builder(Component.literal("<"), button -> changePage(-1))
				.pos(left, 148).size(30, 20).build());
		this.nextButton = this.addRenderableWidget(Button.builder(Component.literal(">"), button -> changePage(1))
				.pos(left + 34, 148).size(30, 20).build());

		this.addRenderableWidget(Button.builder(Component.literal("-"), button -> changeStrength(-1))
				.pos(cx + 22, 148).size(24, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("+"), button -> changeStrength(1))
				.pos(cx + 126, 148).size(24, 20).build());

		int bottom = this.height - 27;
		this.addRenderableWidget(Button.builder(Component.literal("Terapkan"), button -> apply())
				.pos(left, bottom).size(98, 20).build());
		this.lookedButton = this.addRenderableWidget(Button.builder(Component.literal("Blok dilihat"), button -> addLooked())
				.pos(left + 101, bottom).size(98, 20).build());
		this.addRenderableWidget(Button.builder(Component.literal("Tutup"), button -> this.onClose())
				.pos(left + 202, bottom).size(98, 20).build());

		this.lookedButton.active = this.lookedAt != null;
		refreshList();
		updateResults();
	}

	private static String shortName(String id) {
		return id.startsWith("minecraft:") ? id.substring("minecraft:".length()) : id;
	}

	private int pages() {
		return Math.max(1, (this.blocks.size() + PAGE - 1) / PAGE);
	}

	private void updateResults() {
		if (this.search == null) {
			return;
		}
		String query = this.search.getValue().trim().toLowerCase(Locale.ROOT);
		List<String> startsWith = new ArrayList<>();
		List<String> contains = new ArrayList<>();
		if (!query.isEmpty()) {
			for (var key : BuiltInRegistries.BLOCK.keySet()) {
				String id = key.toString();
				if (this.blocks.contains(id)) {
					continue;
				}
				String name = shortName(id);
				if (name.startsWith(query)) {
					startsWith.add(id);
				} else if (id.contains(query)) {
					contains.add(id);
				}
			}
			startsWith.sort(String::compareTo);
			contains.sort(String::compareTo);
		}
		List<String> found = new ArrayList<>(startsWith);
		found.addAll(contains);

		for (int i = 0; i < RESULTS; i++) {
			if (i < found.size()) {
				this.resultIds[i] = found.get(i);
				this.resultButtons[i].setMessage(Component.literal("+ " + shortName(found.get(i))));
				this.resultButtons[i].active = true;
			} else {
				this.resultIds[i] = null;
				this.resultButtons[i].setMessage(Component.literal(""));
				this.resultButtons[i].active = false;
			}
		}
	}

	private void refreshList() {
		this.page = Math.max(0, Math.min(this.page, pages() - 1));
		for (int i = 0; i < PAGE; i++) {
			int index = this.page * PAGE + i;
			if (index < this.blocks.size()) {
				this.listButtons[i].setMessage(Component.literal("[x] " + shortName(this.blocks.get(index))));
				this.listButtons[i].active = true;
			} else {
				this.listButtons[i].setMessage(Component.literal(""));
				this.listButtons[i].active = false;
			}
		}
		this.prevButton.active = this.page > 0;
		this.nextButton.active = this.page < pages() - 1;
	}

	private void addResult(int index) {
		String id = this.resultIds[index];
		if (id == null || this.blocks.contains(id)) {
			return;
		}
		this.blocks.add(id);
		this.page = pages() - 1;
		this.status = "Ditambah: " + shortName(id) + ". Tekan Terapkan.";
		refreshList();
		updateResults();
	}

	private void addLooked() {
		if (this.lookedAt == null) {
			return;
		}
		if (this.blocks.contains(this.lookedAt)) {
			this.status = shortName(this.lookedAt) + " sudah ada di daftar.";
			return;
		}
		this.blocks.add(this.lookedAt);
		this.page = pages() - 1;
		this.status = "Ditambah: " + shortName(this.lookedAt) + ". Tekan Terapkan.";
		refreshList();
		updateResults();
	}

	private void removeAt(int index) {
		int real = this.page * PAGE + index;
		if (real < 0 || real >= this.blocks.size()) {
			return;
		}
		String removed = this.blocks.remove(real);
		this.status = "Dihapus: " + shortName(removed) + ". Tekan Terapkan.";
		refreshList();
		updateResults();
	}

	private void changePage(int delta) {
		this.page += delta;
		refreshList();
	}

	private void changeStrength(int delta) {
		this.strength = PackEditor.clampStrength(this.strength + delta);
		this.status = "Kekuatan diubah. Tekan Terapkan.";
	}

	private void apply() {
		try {
			PackEditor.saveConfig(this.blocks, this.strength);

			String pack = PackEditor.currentPackName();
			if (pack == null) {
				this.status = "Tidak ada shader pack aktif. Pilih iterationT dulu.";
				return;
			}
			Path packPath = PackEditor.shaderpacksDir().resolve(pack);
			String text = PackEditor.readBlockProps(packPath);
			String updated = PackEditor.replaceBlocks(text, this.blocks);
			if (updated == null) {
				this.status = "Pack belum dipasang patch (block.7200 tidak ada).";
				return;
			}
			PackEditor.writeBlockProps(packPath, updated);
			PackEditor.writeStrength(pack, this.strength);

			this.status = "Tersimpan. Memuat ulang shader...";
			Minecraft.getInstance().execute(PackEditor::reloadIrisSafely);
		} catch (ClassNotFoundException e) {
			this.status = "Iris tidak ditemukan.";
		} catch (Exception e) {
			WetBlocksClient.LOGGER.error("Apply failed", e);
			this.status = "Gagal: " + e.getClass().getSimpleName() + " " + e.getMessage();
		}
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		super.render(graphics, mouseX, mouseY, delta);
		int cx = this.width / 2;
		int left = cx - 150;

		graphics.drawCenteredString(this.font, this.title, cx, 8, 0xFFFFFFFF);
		graphics.drawString(this.font, Component.literal("Blok terdaftar: " + this.blocks.size() + "   Hal. " + (this.page + 1) + "/" + pages()),
				left, 90, 0xFFFFFFFF);
		graphics.drawCenteredString(this.font,
				Component.literal(String.format(Locale.ROOT, "Kekuatan: %.1f", this.strength / 10.0)), cx + 86, 154, 0xFFFFFFFF);
		graphics.drawString(this.font, Component.literal(this.status), left, 174, 0xFFFFFF55);
	}

	@Override
	public void onClose() {
		this.minecraft.setScreen(this.parent);
	}
}
