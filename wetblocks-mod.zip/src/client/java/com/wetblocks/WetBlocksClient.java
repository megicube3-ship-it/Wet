package com.wetblocks;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WetBlocksClient implements ClientModInitializer {
	public static final Logger LOGGER = LoggerFactory.getLogger("wetblocks");

	private static KeyMapping openKey;
	private static boolean pendingOpen = false;

	@Override
	public void onInitializeClient() {
		KeyMapping.Category category = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("wetblocks", "main"));
		openKey = KeyBindingHelper.registerKeyBinding(
				new KeyMapping("key.wetblocks.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));

		// /wetblocks opens the menu (the screen is opened on the next tick, after the chat screen has closed)
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
				dispatcher.register(ClientCommandManager.literal("wetblocks").executes(context -> {
					pendingOpen = true;
					return 1;
				})));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openKey.consumeClick()) {
				pendingOpen = true;
			}
			if (pendingOpen && client.screen == null && client.level != null) {
				pendingOpen = false;
				client.setScreen(new WetBlocksScreen(null));
			}
		});

		LOGGER.info("Wet Blocks loaded. Use /wetblocks or the keybind to open the menu.");
	}
}
