package com.wetblocks;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/**
 * Reads and writes the block list (block.7200 in the shader pack's block.properties),
 * the strength option (shaderpacks/<pack>.txt) and our own config file.
 * Iris is accessed through reflection so the mod has no compile-time dependency on it.
 */
public final class PackEditor {
	public static final String BLOCK_KEY = "block.7200";
	public static final String OPTION_KEY = "ALWAYS_WET_STRENGTH";
	public static final int DEFAULT_STRENGTH = 10; // tenths: 10 = 1.0
	public static final int MIN_STRENGTH = 1;
	public static final int MAX_STRENGTH = 20;

	private PackEditor() {
	}

	// ---------------------------------------------------------------- Iris (reflection)

	private static Class<?> irisClass() throws ClassNotFoundException {
		return Class.forName("net.irisshaders.iris.Iris");
	}

	public static Path shaderpacksDir() throws ReflectiveOperationException {
		Method m = irisClass().getMethod("getShaderpacksDirectory");
		return (Path) m.invoke(null);
	}

	/** Name of the active shader pack, or null when shaders are off / internal. */
	public static String currentPackName() throws ReflectiveOperationException {
		Method m = irisClass().getMethod("getCurrentPackName");
		String name = (String) m.invoke(null);
		if (name == null || name.isEmpty() || name.startsWith("(")) {
			return null;
		}
		return name;
	}

	public static void reloadIris() throws ReflectiveOperationException {
		Method m = irisClass().getMethod("reload");
		m.invoke(null);
	}

	public static void reloadIrisSafely() {
		try {
			reloadIris();
		} catch (Exception e) {
			WetBlocksClient.LOGGER.error("Failed to reload Iris", e);
		}
	}

	// ---------------------------------------------------------------- block.properties

	private static boolean isZip(Path pack) {
		return !Files.isDirectory(pack) && pack.toString().toLowerCase(Locale.ROOT).endsWith(".zip");
	}

	/** Finds shaders/block.properties below root (folder pack root or zip root). */
	private static Path findBlockProps(Path root) throws IOException {
		try (Stream<Path> stream = Files.walk(root, 4)) {
			return stream
					.filter(p -> p.getFileName() != null
							&& p.getFileName().toString().equals("block.properties")
							&& p.getParent() != null
							&& p.getParent().getFileName() != null
							&& p.getParent().getFileName().toString().equals("shaders"))
					.min(Comparator.comparingInt(Path::getNameCount))
					.orElse(null);
		}
	}

	public static String readBlockProps(Path pack) throws IOException {
		if (isZip(pack)) {
			try (FileSystem fs = FileSystems.newFileSystem(pack)) {
				Path file = findBlockProps(fs.getPath("/"));
				if (file == null) {
					throw new IOException("shaders/block.properties tidak ditemukan di zip");
				}
				return new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
			}
		}
		Path file = findBlockProps(pack);
		if (file == null) {
			throw new IOException("shaders/block.properties tidak ditemukan di folder pack");
		}
		return new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
	}

	public static void writeBlockProps(Path pack, String text) throws IOException {
		byte[] data = text.getBytes(StandardCharsets.UTF_8);
		if (isZip(pack)) {
			try (FileSystem fs = FileSystems.newFileSystem(pack)) {
				Path file = findBlockProps(fs.getPath("/"));
				if (file == null) {
					throw new IOException("shaders/block.properties tidak ditemukan di zip");
				}
				Files.write(file, data);
			}
			return;
		}
		Path file = findBlockProps(pack);
		if (file == null) {
			throw new IOException("shaders/block.properties tidak ditemukan di folder pack");
		}
		Files.write(file, data);
	}

	private static boolean isBlockLine(String line) {
		String t = line.stripLeading();
		if (!t.startsWith(BLOCK_KEY)) {
			return false;
		}
		String rest = t.substring(BLOCK_KEY.length()).stripLeading();
		return rest.startsWith("=");
	}

	private static boolean continues(String line) {
		return line.stripTrailing().endsWith("\\");
	}

	/** Block ids listed in block.7200 ("namespace:path"), or null when the line does not exist. */
	public static List<String> parseBlocks(String text) {
		String[] lines = text.split("\r?\n", -1);
		for (int i = 0; i < lines.length; i++) {
			if (!isBlockLine(lines[i])) {
				continue;
			}
			StringBuilder value = new StringBuilder();
			int j = i;
			while (true) {
				String line = lines[j];
				if (j == i) {
					line = line.substring(line.indexOf('=') + 1);
				}
				boolean cont = continues(line);
				if (cont) {
					line = line.stripTrailing();
					line = line.substring(0, line.length() - 1);
				}
				value.append(line).append(' ');
				if (!cont || j + 1 >= lines.length) {
					break;
				}
				j++;
			}
			List<String> ids = new ArrayList<>();
			for (String token : value.toString().trim().split("\\s+")) {
				if (token.isEmpty() || token.contains("=")) {
					continue; // block states are not editable here
				}
				String id = token.contains(":") ? token : "minecraft:" + token;
				if (id.equals("minecraft:air")) {
					continue; // placeholder for an empty list
				}
				if (!ids.contains(id)) {
					ids.add(id);
				}
			}
			return ids;
		}
		return null;
	}

	/** Returns the text with the block.7200 line replaced, or null if the line does not exist. */
	public static String replaceBlocks(String text, List<String> ids) {
		String newline = text.contains("\r\n") ? "\r\n" : "\n";
		String[] lines = text.split("\r?\n", -1);
		for (int i = 0; i < lines.length; i++) {
			if (!isBlockLine(lines[i])) {
				continue;
			}
			int end = i;
			while (continues(lines[end]) && end + 1 < lines.length) {
				end++;
			}
			StringBuilder value = new StringBuilder(BLOCK_KEY).append(" =");
			if (ids.isEmpty()) {
				value.append(" air");
			} else {
				for (String id : ids) {
					value.append(' ').append(id.startsWith("minecraft:") ? id.substring("minecraft:".length()) : id);
				}
			}
			StringBuilder out = new StringBuilder();
			for (int k = 0; k < lines.length; k++) {
				if (k == i) {
					out.append(value);
					if (k < lines.length - 1) {
						out.append(newline);
					}
				} else if (k > i && k <= end) {
					continue;
				} else {
					out.append(lines[k]);
					if (k < lines.length - 1) {
						out.append(newline);
					}
				}
			}
			return out.toString();
		}
		return null;
	}

	// ---------------------------------------------------------------- strength option

	private static Path optionsFile(String packName) throws ReflectiveOperationException {
		return shaderpacksDir().resolve(packName + ".txt");
	}

	public static void writeStrength(String packName, int tenths) throws IOException, ReflectiveOperationException {
		Path txt = optionsFile(packName);
		String value = String.format(Locale.ROOT, "%.1f", tenths / 10.0);
		List<String> lines = Files.exists(txt) ? new ArrayList<>(Files.readAllLines(txt, StandardCharsets.UTF_8)) : new ArrayList<>();
		boolean found = false;
		for (int i = 0; i < lines.size(); i++) {
			if (lines.get(i).startsWith(OPTION_KEY + "=")) {
				lines.set(i, OPTION_KEY + "=" + value);
				found = true;
			}
		}
		if (!found) {
			lines.add(OPTION_KEY + "=" + value);
		}
		Files.write(txt, lines, StandardCharsets.UTF_8);
	}

	// ---------------------------------------------------------------- own config (survives pack updates)

	private static Path configFile() {
		return FabricLoader.getInstance().getConfigDir().resolve("wetblocks.txt");
	}

	public static final class Config {
		public final List<String> blocks = new ArrayList<>();
		public int strength = DEFAULT_STRENGTH;
	}

	/** Loads our config; if it does not exist yet, starts from the active pack's list, then from a default. */
	public static Config loadConfig() {
		Config config = new Config();
		Path file = configFile();
		try {
			if (Files.exists(file)) {
				for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
					line = line.trim();
					if (line.isEmpty() || line.startsWith("#")) {
						continue;
					}
					if (line.startsWith("strength=")) {
						try {
							config.strength = clampStrength(Integer.parseInt(line.substring("strength=".length()).trim()));
						} catch (NumberFormatException ignored) {
						}
					} else if (!config.blocks.contains(line)) {
						config.blocks.add(line);
					}
				}
				return config;
			}
		} catch (IOException e) {
			WetBlocksClient.LOGGER.warn("Could not read config", e);
		}
		try {
			String pack = currentPackName();
			if (pack != null) {
				List<String> fromPack = parseBlocks(readBlockProps(shaderpacksDir().resolve(pack)));
				if (fromPack != null) {
					config.blocks.addAll(fromPack);
				}
			}
		} catch (Exception e) {
			WetBlocksClient.LOGGER.debug("Could not read the block list from the pack", e);
		}
		if (config.blocks.isEmpty()) {
			config.blocks.add("minecraft:stripped_spruce_log");
		}
		return config;
	}

	public static void saveConfig(List<String> blocks, int strength) {
		List<String> lines = new ArrayList<>();
		lines.add("# Wet Blocks config: strength in tenths, then one block id per line");
		lines.add("strength=" + clampStrength(strength));
		lines.addAll(blocks);
		try {
			Files.write(configFile(), lines, StandardCharsets.UTF_8);
		} catch (IOException e) {
			WetBlocksClient.LOGGER.warn("Could not save config", e);
		}
	}

	public static int clampStrength(int tenths) {
		return Math.max(MIN_STRENGTH, Math.min(MAX_STRENGTH, tenths));
	}
}
